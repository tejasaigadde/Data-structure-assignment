#include <stdio.h>

int add(int a, int b) { return a + b; }
int sub(int a, int b) { return a - b; }
int mul(int a, int b) { return a * b; }
float div(int a, int b) { return (float)a / b; }

int main() {
    int a, b, ch;

    scanf("%d %d", &a, &b);
    scanf("%d", &ch);

    switch (ch) {
        case 1: printf("%d", add(a,b)); break;
        case 2: printf("%d", sub(a,b)); break;
        case 3: printf("%d", mul(a,b)); break;
        case 4: printf("%.2f", div(a,b)); break;
        default: printf("Invalid choice");
    }
    return 0;
}
