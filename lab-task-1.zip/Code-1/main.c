#include <stdio.h>

int main() {
    int n, bin[32], i = 0;

    scanf("%d", &n);

    while (n > 0) {
        bin[i] = n % 2;
        n = n / 2;
        i++;
    }

    for (i = i - 1; i >= 0; i--)
        printf("%d", bin[i]);

    return 0;
}
